package com.example.animmodel;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class FirstFragment extends Fragment {

    private Button btnTask;
    private AnimationDrawable animationDrawable;
    private ImageView imgCard;
    private ImageView imgCard2;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ConstraintLayout constraint= view.findViewById(R.id.constraint);

        constraint.setAnimation(AnimationUtils.loadAnimation(getActivity(),R.anim.fade_transition_animation));
        animationDrawable = (AnimationDrawable) constraint.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();
        view.findViewById(R.id.btnAdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });

        btnTask = view.findViewById(R.id.btnTask);
        btnTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgCard.setAnimation(AnimationUtils.loadAnimation(getActivity(),R.anim.fade_transition_animation));
                imgCard2.setAnimation(AnimationUtils.loadAnimation(getActivity(),R.anim.fade_transition_animation));
            }
        });


       btnTask.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               imgCard = view.findViewById(R.id.imgCard);
               imgCard2 = view.findViewById(R.id.imgCard2);
           }
       });

    }
}