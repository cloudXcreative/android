package com.example.recyclerview_v_1;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class FirstFragment extends Fragment {
List<String> birds=new ArrayList<String>();
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        birds.add("parrot");
        birds.add("eagle");
        birds.add("sparrow");
       




        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView birdRV=view.findViewById(R.id.birdRV);
        birdRV.setLayoutManager(new LinearLayoutManager(getActivity()));
        BirdAdapter adapter = new BirdAdapter(getActivity(),R.layout.row_birds,birds);
        birdRV.setAdapter(adapter);
    }

        class BirdAdapter extends RecyclerView.Adapter<BirdAdapter.Holder> {
            private final Context context;
            private final int layout;
            private final List<String> birds;
            private final LayoutInflater inflater;
            public BirdAdapter(Context context, int layout, List<String> birds) {
                this.context=context;
                this.layout=layout;
                this.birds=birds;
                inflater = LayoutInflater.from(context);
            }






            @NonNull
            @Override
            public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = inflater.inflate(layout,parent,false);
                return new Holder(view);
            }

            @Override
            public void onBindViewHolder(@NonNull Holder holder, int position) {
                String birdsName= birds.get(position);
                holder.textBirds.setText(birdsName);
            }

            @Override
            public int getItemCount() {
                return birds.size();
            }

            public class Holder extends  RecyclerView.ViewHolder {
                TextView textBirds;
                public Holder(@NonNull View itemView) {
                    super(itemView);
                    textBirds=itemView.findViewById(R.id.textBirds);
                }
            }


    }
}