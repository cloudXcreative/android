package com.example.findtheauthor;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {

    private Button btnSearch;
    private TextView bookName;
    private TextView bookAuthor;
    private EditText editName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editName = findViewById(R.id.editName);
        btnSearch = findViewById(R.id.btnSearch);
        bookName = findViewById(R.id.bookName);
        bookAuthor = findViewById(R.id.bookAuthor);
        hideSystemUI();
        if(getSupportLoaderManager().getLoader(0)!=null){
            getSupportLoaderManager().initLoader(0,null,this);
        }

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager inputMethodManager= (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if(inputMethodManager!=null){
                    inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),inputMethodManager.HIDE_NOT_ALWAYS);
                }
                Context context;
                ConnectivityManager connMgr = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                if(connMgr!=null){
                    NetworkInfo networkInfo=connMgr.getActiveNetworkInfo();
                    if((networkInfo != null) && networkInfo.isConnected()){
                        searchBook();
                        bookName.setText("");
                        bookAuthor.setText("loading.....");
                    }
                    else
                        bookAuthor.setText("");
                        bookName.setText("No network check connection");
                }

            }
        });
    }
    public void  searchBook(){
        String queryString =editName.getText().toString();

        if(queryString.length()>2) {
         /*   new FetchBook(bookName, bookAuthor).execute(queryString);*/
            Bundle queryBundle=new Bundle();
            queryBundle.putString("query",queryString);
            getSupportLoaderManager().restartLoader(0,queryBundle,this);
        }
        else{
            editName.setError("enter a book name");
            editName.requestFocus();
        }
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {
        String query="";
        if(args!=null){
          query=  args.getString("query");
        }
        return new BookLoader(this,query);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        try {
            // 1. raw string to JSONObject
            JSONObject jsonObject = new JSONObject(data);
            // 2. get the book data array
            JSONArray itemsArray = jsonObject.getJSONArray("items");

            // 3. loop variables
            int i = 0;
            String title = null;
            String authors = null;

            // 4. Look for results in array, exit when both title and author are found
            // or when all items are checked
            while (i < itemsArray.length() && (authors == null && title == null)) {
                JSONObject book = itemsArray.getJSONObject(i);
                JSONObject volume = book.getJSONObject("volumeInfo");
                try {
                    title = volume.getString("title");
                    authors = volume.getString("authors");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                i++;
            }
            if (title != null && authors != null) {
                bookName.setText(title);
                bookAuthor.setText(authors);
            } else {
                bookName.setText("Unknown Book Name");
                bookAuthor.setText("No results found");
            }

        } catch (Exception e) {
            e.printStackTrace();
            bookName.setText("API error");
            bookAuthor.setText("Please check Logcat");
        }
    }
    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
    //create async task
   /* public class FetchBook extends AsyncTask<String,Void,String>{
        private WeakReference<TextView> textTitle;
        private WeakReference<TextView> textAuthor;

        //constructor


        public FetchBook(TextView textTitle, TextView textAuthor) {
            this.textTitle= new WeakReference<>(textTitle);
            this.textAuthor =  new WeakReference<>(textAuthor);

        }

        @Override
        protected String doInBackground(String... query) {
            //make a request to api server
            return NetworkUtils.getBookInfo(query[0]);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            //parse the JSON data
            try {
                //1. raw String data to JSON object
                JSONObject jsonObject=new JSONObject(result);
                //2.get the book data array
                JSONArray itemArray=jsonObject.getJSONArray("items");
                //3.loop variables

                int i=0;
                String title=null;
                String author=null;
                // 4. look for results in array ,exit when both title and author are found
                // when all items are break
                while (i<itemArray.length()&&(author==null && title == null))
                {
                    JSONObject book=itemArray.getJSONObject(i);
                    JSONObject volume=book.getJSONObject("volumeInfo");
                    try {
                        title=volume.getString("title");
                        author=volume.getString("authors");
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                    i++;
                }
                if (title!=null && author !=null){
                    textTitle.get().setText(title);
                    textAuthor.get().setText(author);
               }
                else{
                    textTitle.get().setText("unknown book name");
                    textAuthor.get().setText("no result found");}




            } catch (Exception e)
            {
                e.printStackTrace();
                textTitle.get().setText("api error");
                textAuthor.get().setText("please check error");
            }



        }
    }*/
    //create network utils log and create an URI

    public void hideSystemUI() {
/*
        View decorView = getWindow().getDecorView();
*/
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        );

    }
}
